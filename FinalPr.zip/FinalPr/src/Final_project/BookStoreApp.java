/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;

/**
 *
 * @author Naga Sreeja
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.event.ActionEvent;

public class BookStoreApp extends Application {
        Scene ownerStart;
        private final File file = new File("books.txt");
	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void start(Stage bookAppViewStage) throws Exception {

		TableView<Book> tableView = new TableView<>();

		TableColumn<Book, String> bookName = new TableColumn<>("Book Name");
		bookName.setCellValueFactory(new PropertyValueFactory<>("bookName"));

		TableColumn<Book, Double> bookPrice = new TableColumn<>("Book Price $");
		bookPrice.setCellValueFactory(new PropertyValueFactory<>("bookPrice"));

		tableView.getColumns().add(bookName);
		tableView.getColumns().add(bookPrice);

		// adding labes
		Label name = new Label("Book Name: ");
		Label price = new Label("Book Price:");

		// adding the textbox
		TextField bookNameBox = new TextField();
		bookNameBox.setPromptText("book name");
		bookNameBox.setMinWidth(100);

		TextField priceBox = new TextField();
		priceBox.setPromptText("0.00");
		bookNameBox.setMinWidth(100);

		// adding buttons and functionalities
		Button addBookBtn = new Button("Add");
		addBookBtn.setOnAction((ActionEvent e) -> {
                    boolean add = tableView.getItems()
                            .add(new Book(bookNameBox.getText(), Double.parseDouble(priceBox.getText())));
			bookNameBox.clear();
			priceBox.clear();
		});
		
		//Implementing the Delete Functionality
		Button deleteBookBtn = new Button("Delete");
        deleteBookBtn.setOnAction(e -> 
        {
        	Book selectedBook = tableView.getSelectionModel().getSelectedItem();
        	tableView.getItems().remove(selectedBook);
        });
        
        //Back Button functionality
        Button backBookBtn = new Button("Back");
//        backBookBtn.setOnAction((ActionEvent e) -> 
//        {
//            window.close();
//        });
		// adding a lyaout for the buttons
		HBox hBoxaddBook = new HBox(15);
		hBoxaddBook.setAlignment(Pos.CENTER);
		hBoxaddBook.getChildren().addAll(name, bookNameBox, price, priceBox,addBookBtn);
                HBox h1boxaddBook = new HBox(100);
                h1boxaddBook.setAlignment(Pos.BOTTOM_CENTER);
                h1boxaddBook.getChildren().addAll(deleteBookBtn, backBookBtn);
                
		VBox bookStoreScreenBox = new VBox(20);

		bookStoreScreenBox.getChildren().addAll(tableView, hBoxaddBook,h1boxaddBook);

		Scene scene = new Scene(bookStoreScreenBox, 700, 650);

		bookAppViewStage.setScene(scene);

		bookAppViewStage.show();

	} 
        
     
}
	


