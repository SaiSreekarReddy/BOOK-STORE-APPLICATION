/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;

/**
 *
 * @author Naga Sreeja
 */
public class Customer extends User {
    
    static int points;
    static String status;

    Customer(String mark, String string, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public String getStatus() {
        return status;
    }
    
    public static String PointsToStatus(int points) {
        
        if (points < 1000) {
            status = "silver";
        }
        
        else if (points >= 1000) {

            status = "gold";
        }
        
        return status;
    }
    
    public String toString() {
        String username = null;
        
        return "Welcome" + " " + username + ". You have: " + points + " points. Your status is " + status + ".";
        
    }
    
    
    public String toString2() {
        
        return "You now have: " + points + " points. Your updated status is: " + status + ".";
        
    }
}

    

