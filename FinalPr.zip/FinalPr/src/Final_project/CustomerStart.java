/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;
import java.util.ArrayList;
import javafx.collections.ObservableList;

/**
 *
 * @author Naga Sreeja
 */
public class CustomerStart {
    static double TotalCost;
    static ObservableList<Book> SelectedBookss;
    static int TotalPoints;
    public CustomerStart() {
      
        
    }
    
     public static int UpdatePoints(int points, double totalcost) {
        
        int updatedPoints;
        updatedPoints = points + (int)totalcost*100;
        return updatedPoints;
    }
    
    
    
    public static void Buy(Customer A, ObservableList<Book> SelectedBoookks) {
        try {
          
          
          SelectedBookss = SelectedBoookks;
          TotalCost = 0;
          for(int l = 0; l < SelectedBookss.size(); l++) {  
          
          TotalCost += SelectedBookss.get(l).getBookPrice();
          
          }
          int updatedpoints = UpdatePoints(A.getPoints(), TotalCost);
          A.setPoints(updatedpoints);
          System.out.println(A.getPoints());
          System.out.println(TotalCost); 
          }
          
          catch (Exception e) {
              System.out.println("Add a book to your cart before clicking buy");
          }
        
        
        
    }
}


