/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;

/**
 *
 * @author Naga Sreeja
 */
public abstract class Customer_Cost_Screen extends Application {
    

    static Customer A = new Customer ("Mark", "123", 1000);
    double TotalCost;
    ObservableList <Book> SelectedBookss;
    Scene CustomerCostScreen; 
    
    public Customer_Cost_Screen() {
        
    }
    
    public static int UpdatePoints(int points, int totalcost) {
        
        int updatedPoints;
        updatedPoints = points + totalcost*100;
        return updatedPoints;
    }
    
    
    public static String PrintUpdatedInfo() {
        UpdatePoints(A.getPoints(), 100);
       A.PointsToStatus(A.getPoints());
       return A.toString2();
       
    }
      public static String TotalCostString(double TotalCost) {
        
        return "Total Cost: " + TotalCost;
    }
}
    

