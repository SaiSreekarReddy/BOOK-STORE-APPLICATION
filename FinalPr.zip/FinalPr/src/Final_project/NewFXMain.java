/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox; 
import javafx.stage.Stage;

/**
 *
 * @author Shahmeer
 */
public class NewFXMain extends Application {
    
    Stage stage;
    Scene ownerStart, ownerBooks, ownerCustomers, ownerLogout;
    
    @Override
    public void start(Stage primaryStage) {
        
        stage = primaryStage;
        
        Label label1 = new Label ("Welcome!/nYou are logged in as owner.");
        Button button1 = new Button("Books");
        Button button2 = new Button("Customers");
        Button button3 = new Button("Logout");
        
        button1.setOnAction(e -> stage.setScene(ownerBooks));
        button2.setOnAction(e -> stage.setScene(ownerCustomers));
        button3.setOnAction(e -> stage.setScene(ownerLogout));
     
        //layout 1
        VBox layout1 = new VBox (40);
        layout1.getChildren().addAll(label1, button1, button2, button3);
        ownerStart = new Scene (layout1, 500, 500);
        
        Button button4 = new Button("Back");
        button4.setOnAction(e -> stage.setScene(ownerStart));
        
        //layout 2
        VBox layout2 = new VBox (40);
        layout2.getChildren().addAll(label1, button4);
        ownerCustomers = new Scene (layout2, 500, 500);
        
        stage.setTitle("Bookstore Application");
        stage.setScene(ownerStart);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}


