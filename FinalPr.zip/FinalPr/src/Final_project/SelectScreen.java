/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;



import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;



public class SelectScreen extends Application {
    
    Scene CustomerStartScreen, CustomerCostScreen;
    Stage screen;
    Customer A = new Customer ("Mark", "123", 1000);
    double TotalCost;
    TableView<Book> table;
    ObservableList <Book> SelectedBookss;
     
    public SelectScreen() {
        
    }

    public String PrintWelcomeMessage() {
       A.PointsToStatus(A.getPoints());
       return A.toString();
       
    }
    
    
     public ObservableList <Book> getBook(){ 
            
            ObservableList<Book> books = FXCollections.observableArrayList();
            books.add(new Book("Book 1", 100));
            books.add(new Book("Book 2", 100));
            books.add(new Book("Book 3", 100));
            books.add(new Book("Book 4", 100));
            books.add(new Book("Book 5", 100));
            
            return books;
        }
    
     public String TotalCostString(double TotalCost) {
        
        return "Total Cost: " + TotalCost;
    }
    
        
    @Override
    public void start(Stage primaryStage) {
        
        
        screen = primaryStage;
        
        TableColumn<Book, String> namecolumn = new TableColumn<>("Name");  
        namecolumn.setMinWidth(200);    
        namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        
       TableColumn<Book, Double> pricecolumn = new TableColumn<>("Price");  
       pricecolumn.setMinWidth(200);    
       pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        
    /*   TableColumn<Book, CheckBox> selectcolumn = new TableColumn<>("Select");  
       pricecolumn.setMinWidth(50);    
       pricecolumn.setCellValueFactory(new PropertyValueFactory<>("select"));
       
       */
       
        table = new TableView<>();
        table.setItems(getBook());
        table.getColumns().addAll(namecolumn, pricecolumn);
       
        
        
        table.setEditable(true);
        table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        table.getSelectionModel().setCellSelectionEnabled(true);
        
        
        Button select = new Button();
        select.setText("Add to cart");
        select.setOnAction((ActionEvent Select) -> {
            
       
        SelectedBookss = table.getSelectionModel().getSelectedItems();    
        for(int i = 0; i < SelectedBookss.size(); i++) {
        System.out.println(SelectedBookss.get(i).getBookName());   
        }
        });
        
        
        Button buy = new Button();
        buy.setText("Buy");
        buy.setOnAction((ActionEvent Buy) -> {
               
         Buy(A, SelectedBookss);
         for(int l = 0; l < SelectedBookss.size(); l++) { 
          TotalCost += SelectedBookss.get(l).getBookPrice();
         }
         SetCustomerCostScreen(A, TotalCost);
         screen.setScene(CustomerCostScreen);   
        });
        
        
        
        Button redeem = new Button();
        redeem.setText("Redeem Points and Buy");
        redeem.setOnAction((ActionEvent Redeem) -> {
            
            try {
           
          int points = A.getPoints();
          TotalCost = 0;
          for(int l = 0; l < SelectedBookss.size(); l++) {  
          
          TotalCost += SelectedBookss.get(l).getBookPrice();             
          }
          
           if (points >= 100) {
              
              TotalCost = TotalCost - points * 0.01;
              System.out.println(TotalCost);
           }
            }
            catch (Exception e) {
              System.out.println("Add a book to your cart before clicking buy");
          }
            });
         
         /*
         //Get evertything in the table
          Book book = new Book();
        List <List<String>> arrList=new ArrayList<>();
        for (int i = 0; i <table.getItems().size() ; i++) {
            book=table.getItems().get(i);
            arrList.add(new ArrayList<>());
            arrList.get(i).add(book.getName());
            arrList.get(i).add(""+book.getPrice());
        }
        for (int i = 0; i < arrList.size(); i++) {
            for (int j = 0; j < arrList.get(i).size(); j++) {
                System.out.print(arrList.get(i).get(j)+" ");
            }
            System.out.println();
        }*/
      
        
        Button logout = new Button();
        logout.setText("Logout");
        logout.setOnAction((ActionEvent Logout) -> {
            System.exit(0);
        });
        
        
        
        
        VBox vboxCustomerStart = new VBox(20);
        vboxCustomerStart.setPadding(new Insets(10,0,10,0));
        CustomerStartScreen = new Scene(vboxCustomerStart,600,520);
        
        Text Welcome = new Text(PrintWelcomeMessage());
        Welcome.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
        
        HBox hboxCustomerStart = new HBox(100);
        hboxCustomerStart.setAlignment(Pos.BOTTOM_CENTER);
        hboxCustomerStart.getChildren().addAll(buy, redeem, select, logout);
        
        vboxCustomerStart.getChildren().addAll(Welcome, table, hboxCustomerStart);
        
        primaryStage.setTitle("Bookstore Application");
        primaryStage.setScene(CustomerStartScreen);
        primaryStage.show();
    }

    private void Buy(Customer A, ObservableList<Book> SelectedBookss) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void SetCustomerCostScreen(Customer A, double TotalCost) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     *
     * @param A
     * @param TotalCost
     */
    public void SetcustomerCostScreen(Customer A, double TotalCost) {
    
      
        VBox vboxCustomerCost = new VBox(20);
        vboxCustomerCost.setPadding(new Insets(50,20,50,20));
        CustomerCostScreen = new Scene(vboxCustomerCost,600,520);
         Text Total = new Text(TotalCostString(TotalCost));
         Total.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
         Text Update = new Text("Updated Points: " + A.getPoints()) ;
         Update.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
         
         Button logout = new Button();
        logout.setText("Logout");
        logout.setOnAction((ActionEvent Logout) -> {
            System.exit(0);
        });
         
        HBox hboxCustomerCost = new HBox(100);
        hboxCustomerCost.setAlignment(Pos.BOTTOM_CENTER);
        hboxCustomerCost.getChildren().add(logout);
        vboxCustomerCost.getChildren().addAll(Total, Update, hboxCustomerCost);
        
        
        
        }
    
  
    
    
    
       
    

    public static void main(String[] args) {
        launch(args);
    }
}

