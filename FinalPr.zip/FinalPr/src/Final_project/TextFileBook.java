/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final_project;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;

public class TextFileBook 
{
    
    private String inputFile; 
    

    private static TextFileBook instance = null; 
    
    
    private TextFileBook(String n)
    {
        inputFile = n; 
    }
    
    public static TextFileBook getInstance()
    {
        if (instance == null)
        {
            instance = new TextFileBook("booktext.txt");
        }
        return instance;
    }
    
    public ObservableList<Book> read() 
    {
        ObservableList<Book> books = FXCollections.observableArrayList();
        try 
        {
            FileReader readF = new FileReader(this.inputFile);
            Scanner sc = new Scanner(readF);
                       
            while (sc.hasNextLine()) 
            {
                String line = sc.nextLine(); 
                String[] details = line.split(",");
                String name = details[0];
                double price = Double.parseDouble(details[1]);
                books.add(new Book(name, price));
            }}
        catch (IOException e) 
        {
            System.out.println("No books.");
        }
        
        return books;
    }
    public void write(String nameBook, String price) 
    {
        try 
        {
            FileWriter Writewith = new FileWriter(this.inputFile,true);
            BufferedWriter printF = new BufferedWriter(Writewith);
            
            printF.write(nameBook + "," + price);
            printF.newLine();
            printF.close();
        } 
        catch (IOException e) 
        {
            System.out.println("No books to write");
        }}}
